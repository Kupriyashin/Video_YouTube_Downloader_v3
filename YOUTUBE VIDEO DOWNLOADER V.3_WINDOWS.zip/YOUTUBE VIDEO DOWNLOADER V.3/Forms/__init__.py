from loguru import logger

from Forms.Form_downloader import Ui_Form

logger.info("Импортировал класс Ui_Form")